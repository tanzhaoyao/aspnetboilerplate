﻿Simple task system - Core (domain) layer.
-----------------------------------------

This layer includes Entities, Repository interfaces and other domain members.