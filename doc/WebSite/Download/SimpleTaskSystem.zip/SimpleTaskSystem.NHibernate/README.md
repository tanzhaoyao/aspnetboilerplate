﻿Simple task system - Nhibernate infrastructure module
-----------------------------------------

This layer is used to create classes to work with NHibernate. It implements repositories and database migrations.

NHibernate specific codes are placed in this seperated class library. Thus, our domain and application are isolated from NHibernate.