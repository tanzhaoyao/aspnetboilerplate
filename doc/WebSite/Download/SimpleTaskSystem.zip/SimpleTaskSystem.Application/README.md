﻿Simple task system - Application (service) layer.
-----------------------------------------

This layer contains application services and DTOs. Application layer is used by presentation layer and uses domain (core) layer to perform application specific operations.