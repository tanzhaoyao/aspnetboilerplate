﻿Simple task system - Web API (remote façade) layer.
-----------------------------------------

This layer is used to create a Web API layer on top of Application layer.