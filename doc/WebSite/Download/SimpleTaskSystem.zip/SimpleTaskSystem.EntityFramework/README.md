﻿Simple task system - EntityFramework infrastructure module
-----------------------------------------

This layer is used to create classes to work with EntityFramework. It implements repositories and database migrations.

NHibernate specific codes are placed in this seperated class library. Thus, our domain and application are isolated from EntityFramework.